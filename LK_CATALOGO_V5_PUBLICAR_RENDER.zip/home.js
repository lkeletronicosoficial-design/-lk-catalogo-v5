LKUI.mountChrome('home');
const s=LKUI.settings(),products=LKUI.products().filter(p=>p.active!==false),rawCats=LKUI.categories();
const storyOrder=['iluminacoes','microfones','estabilizadores','tripes','mochilas-cases','armazenamentos','fones-bluetooth','fones-retorno','carregadores','adaptadores','acessorios','criadores'];
const cats=[...rawCats].sort((a,b)=>storyOrder.indexOf(a.slug)-storyOrder.indexOf(b.slug));
const categoryImages={iluminacoes:'assets/cat-iluminacoes.jpeg',microfones:'assets/cat-microfones.jpeg',estabilizadores:'assets/cat-estabilizadores.jpeg',tripes:'assets/cat-tripes.jpeg','mochilas-cases':'assets/cat-mochilas-cases.jpeg',armazenamentos:'assets/cat-armazenamentos.jpeg','fones-bluetooth':'assets/cat-fones-bluetooth.jpeg','fones-retorno':'assets/cat-fones-retorno.jpeg',carregadores:'assets/cat-carregadores.jpeg',adaptadores:'assets/cat-adaptadores.jpeg',acessorios:'assets/cat-acessorios-geral.jpeg',criadores:'assets/cat-criadores.jpeg'};
document.getElementById('featuredTitle').textContent=s.featuredTitle||'Destaques';
document.getElementById('categoryGrid').innerHTML=cats.map(c=>'<div class="simply-story-item"><a class="simply-story-img" href="catalogo.html?categoria='+encodeURIComponent(c.slug)+'"><img src="'+(categoryImages[c.slug]||'assets/cat-criadores.jpeg')+'" alt="'+LKUI.esc(c.name)+'"></a><a class="simply-story-title" href="catalogo.html?categoria='+encodeURIComponent(c.slug)+'">'+LKUI.esc(c.name)+'</a></div>').join('');
const featured=products.filter(p=>p.showHome!==false).sort((a,b)=>(a.featured||999)-(b.featured||999)).slice(0,12);
document.getElementById('featuredGrid').innerHTML=featured.map(p=>LKUI.productCard(p)).join('');
LKUI.bindAddButtons(document);
const slides=[...document.querySelectorAll('.simply-banner-slide')],dots=[...document.querySelectorAll('.simply-banner-dots button')];
let current=0,timer;
function showSlide(i){current=(i+slides.length)%slides.length;slides.forEach((el,n)=>el.classList.toggle('active',n===current));dots.forEach((el,n)=>el.classList.toggle('active',n===current));}
function start(){clearInterval(timer);timer=setInterval(()=>showSlide(current+1),5000);}
dots.forEach((b,i)=>b.addEventListener('click',()=>{showSlide(i);start();}));
showSlide(0);start();