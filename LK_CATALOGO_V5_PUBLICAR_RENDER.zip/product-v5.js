LKUI.mountChrome('');
document.getElementById('floatingWa')?.remove();

const id=new URLSearchParams(location.search).get('id');
const p=LKUI.products().find(x=>x.id===id&&x.active!==false);
const root=document.getElementById('productPage');

if(!p){
  root.innerHTML='<div class="empty-results"><strong>Produto não encontrado.</strong><span>Ele pode ter sido removido ou estar temporariamente indisponível.</span><br><br><a class="secondary-action" href="catalogo.html">Voltar ao catálogo</a></div>';
  throw new Error('Product not found');
}

document.title=p.name+' | LK Eletrônicos';
document.querySelector('meta[name="description"]').content=p.subtitle||p.description||'';

let variation=(p.variations||[])[0]||'';
let qty=1;
const images=(p.images||[]).filter(Boolean);
const discount=productDiscount(p);
const sold=LKUI.isSoldout(p);
const category=LKUI.categoryName(p.category);

const gallery=images.length
  ? '<div class="simply-product-gallery"><div class="simply-gallery-main"><img id="mainImg" src="'+LKUI.esc(images[0])+'" alt="'+LKUI.esc(p.name)+'"></div>'+(images.length>1?'<div class="simply-gallery-thumbs">'+images.map((img,i)=>'<button class="'+(i===0?'active':'')+'" data-img="'+LKUI.esc(img)+'"><img src="'+LKUI.esc(img)+'" alt="Foto '+(i+1)+'"></button>').join('')+'</div>':'')+'</div>'
  : '<div class="simply-product-gallery"><div class="simply-gallery-main">'+LKUI.imageMarkup(p)+'</div></div>';

const oldPrice=p.oldPrice&&Number(p.oldPrice)>Number(p.price)
  ? '<span class="simply-old-price">'+LKUI.money(p.oldPrice)+'</span>'
  : '';

const variationBlock=(p.variations||[]).length
  ? '<div class="simply-option-row"><label for="variantSelect">ESCOLHA O MODELO:</label><select id="variantSelect">'+p.variations.map(v=>'<option value="'+LKUI.esc(v)+'">'+LKUI.esc(v)+'</option>').join('')+'</select></div>'
  : '';

const quantityBlock=!sold
  ? '<div class="simply-option-row"><label>QUANTIDADE</label><div class="simply-qty"><button id="qtyMinus">−</button><input id="qtyInput" type="number" min="1" value="1"><button id="qtyPlus">＋</button></div></div>'
  : '';

const features=(p.specs||[]).length
  ? '<div class="simply-features"><strong>Principais Características</strong><ul id="featureList">'+p.specs.map(s=>'<li>'+LKUI.esc(s)+'</li>').join('')+'</ul><button id="featureToggle" type="button">Ver mais <span>⌄</span></button></div>'
  : '';

root.innerHTML=
'<div class="simply-breadcrumb"><a href="index.html">Voltar para a página inicial</a><span>›</span><a href="catalogo.html?categoria='+encodeURIComponent(p.category)+'">'+LKUI.esc(category)+'</a><span>›</span><span>'+LKUI.esc(p.name)+'</span></div>'+
'<section class="simply-product-layout">'+
  gallery+
  '<div class="simply-product-info">'+
    '<h1>'+LKUI.esc(p.name)+'</h1>'+
    '<p class="simply-product-desc">'+LKUI.esc(p.description||p.subtitle||'')+'</p>'+
    features+
    '<div class="simply-price-line"><strong>'+LKUI.money(p.price)+'</strong>'+oldPrice+(discount?'<span class="simply-discount">-'+discount+'%</span>':'')+'</div>'+
    '<div class="simply-installments"><span class="card-outline">▣</span><div><strong>12x</strong> com juros no cartão<br>de crédito. <b>(ver parcelas)</b></div></div>'+
    variationBlock+
    quantityBlock+
    '<div class="simply-product-actions">'+
      (sold
        ? '<a class="simply-whatsapp-btn full" id="notifyWa" href="#" target="_blank" rel="noopener">Avise-me pelo WhatsApp</a>'
        : '<a class="simply-whatsapp-btn" id="buyWa" href="#" target="_blank" rel="noopener">◉ Compra rápida pelo WhatsApp</a><button class="simply-cart-btn" id="addProduct">Adicionar ao carrinho</button>')+
    '</div>'+
  '</div>'+
'</section>'+
'<section class="simply-related"><h2>Produtos relacionados</h2><div class="products-grid simply-category-grid" id="relatedGrid"></div></section>';

if(images.length>1){
  document.querySelectorAll('[data-img]').forEach(b=>b.addEventListener('click',()=>{
    document.getElementById('mainImg').src=b.dataset.img;
    document.querySelectorAll('[data-img]').forEach(x=>x.classList.toggle('active',x===b));
  }));
}
document.getElementById('variantSelect')?.addEventListener('change',e=>{variation=e.target.value});
function setQty(v){
  qty=Math.max(1,Number(v)||1);
  const input=document.getElementById('qtyInput');
  if(input)input.value=qty;
  updateWa();
}
document.getElementById('qtyMinus')?.addEventListener('click',()=>setQty(qty-1));
document.getElementById('qtyPlus')?.addEventListener('click',()=>setQty(qty+1));
document.getElementById('qtyInput')?.addEventListener('change',e=>setQty(e.target.value));

function waText(){
  return 'Olá! Tenho interesse no '+p.name+(variation?' ('+variation+')':'')+'. Quantidade: '+qty+'. Valor: '+LKUI.money(p.price)+'. Link: '+location.href;
}
function updateWa(){
  const el=document.getElementById('buyWa');
  if(el)el.href=LKUI.genericWa(waText());
}
updateWa();

document.getElementById('addProduct')?.addEventListener('click',()=>{
  if(LKUI.addToCart(p.id,qty,variation))LKUI.openCart();
});
const notify=document.getElementById('notifyWa');
if(notify)notify.href=LKUI.genericWa('Olá! Avise-me quando o produto '+p.name+' estiver disponível. Link: '+location.href);

const featureToggle=document.getElementById('featureToggle');
if(featureToggle){
  featureToggle.addEventListener('click',()=>{
    document.querySelector('.simply-features').classList.toggle('open');
    featureToggle.innerHTML=document.querySelector('.simply-features').classList.contains('open')?'Ver menos <span>⌃</span>':'Ver mais <span>⌄</span>';
  });
}

const related=LKUI.products().filter(x=>x.active!==false&&x.id!==p.id&&x.category===p.category).slice(0,4);
document.getElementById('relatedGrid').innerHTML=related.map(x=>LKUI.productCard(x)).join('');
LKUI.bindAddButtons(document);