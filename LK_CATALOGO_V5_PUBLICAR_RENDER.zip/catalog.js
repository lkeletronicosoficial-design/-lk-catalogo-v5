const params=new URLSearchParams(location.search);
let mode=params.get('modo')||'';
let category=params.get('categoria')||'';
let q=(params.get('q')||'').trim();
let sort='relevance';
let visible=20;

LKUI.mountChrome(mode==='ofertas'?'offers':mode==='novidades'?'news':'categories');
const all=LKUI.products().filter(p=>p.active!==false);

function matches(p){
  if(category&&p.category!==category)return false;
  if(mode==='ofertas'&&!(p.oldPrice&&Number(p.oldPrice)>Number(p.price)))return false;
  if(mode==='novidades')return true;
  if(q){
    const text=(p.name+' '+(p.subtitle||'')+' '+(p.brand||'')+' '+(p.sku||'')+' '+LKUI.categoryName(p.category)).toLowerCase();
    if(!text.includes(q.toLowerCase()))return false;
  }
  return true;
}
function sorted(list){
  list=[...list];
  if(sort==='priceAsc')return list.sort((a,b)=>Number(a.price)-Number(b.price));
  if(sort==='priceDesc')return list.sort((a,b)=>Number(b.price)-Number(a.price));
  if(sort==='news')return list.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)||String(b.id).localeCompare(String(a.id)));
  if(sort==='discount')return list.sort((a,b)=>((b.oldPrice?1-b.price/b.oldPrice:0)-(a.oldPrice?1-a.price/a.oldPrice:0)));
  if(mode==='novidades')return list.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)||String(b.id).localeCompare(String(a.id)));
  return list.sort((a,b)=>(a.featured||999)-(b.featured||999));
}
function title(){
  if(mode==='ofertas')return 'Ofertas';
  if(mode==='novidades')return 'Novidades';
  if(category)return LKUI.categoryName(category);
  if(q)return 'Resultados para “'+q+'”';
  return 'Todos os produtos';
}
function render(){
  const list=sorted(all.filter(matches));
  const t=title();
  document.getElementById('catalogTitle').textContent=t;
  document.title=t+' | LK Eletrônicos';
  document.getElementById('resultCount').textContent=list.length+' produto'+(list.length===1?'':'s');
  document.getElementById('catalogGrid').innerHTML=list.slice(0,visible).map(p=>LKUI.productCard(p)).join('');
  document.getElementById('emptyResults').hidden=!!list.length;
  document.getElementById('loadMore').hidden=visible>=list.length;
  LKUI.bindAddButtons(document);
}
document.getElementById('sortToggle').addEventListener('click',()=>{const label=document.getElementById('sortLabel'),arrow=document.getElementById('sortArrow');if(sort==='relevance'){sort='priceDesc';label.textContent='Menor Preço';arrow.textContent='↓'}else if(sort==='priceDesc'){sort='priceAsc';label.textContent='Relevância';arrow.textContent='↕'}else{sort='relevance';label.textContent='Maior Preço';arrow.textContent='↑'}render()});
document.getElementById('loadMore').addEventListener('click',()=>{visible+=20;render()});
render();