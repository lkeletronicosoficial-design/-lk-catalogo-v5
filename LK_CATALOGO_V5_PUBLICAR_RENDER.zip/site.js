const LKUI = (()=>{
  let settings=getLKSettings();
  let categories=getLKCategories();
  let products=getLKProducts();
  let cart=getLKCart();
  const $=(q,root=document)=>root.querySelector(q);
  const $$=(q,root=document)=>[...root.querySelectorAll(q)];
  const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const money=lkMoney;
  const categoryName=slug=>categories.find(c=>c.slug===slug)?.name||slug||'';
  function refresh(){settings=getLKSettings();categories=getLKCategories();products=getLKProducts();cart=getLKCart();}
  function applyTheme(){
    refresh();
    document.documentElement.style.setProperty('--accent',settings.primaryColor||'#31DDDA');
    document.documentElement.style.setProperty('--bg',settings.backgroundColor||'#0A0C0E');
    document.documentElement.style.setProperty('--radius',`${Number(settings.cardRadius||22)}px`);
    document.title=document.title.includes('|')?document.title:(settings.seoTitle||'LK Eletrônicos | Catálogo Digital');
    const meta=$('meta[name="description"]'); if(meta) meta.content=settings.seoDescription||'';
  }
  function genericWa(text='Olá! Gostaria de atendimento da LK Eletrônicos.'){
    return `https://wa.me/${settings.whatsapp}?text=${encodeURIComponent(text)}`;
  }
  function header(active=''){
    const catLinks=categories.map(c=>`<a href="catalogo.html?categoria=${encodeURIComponent(c.slug)}">${esc(c.name)}</a>`).join('');
    return `<header class="site-header-v5 simply-header">
      <div class="simply-mobile-logo"><a href="index.html"><img src="assets/logo-original.webp" alt="LK Eletrônicos"></a></div>
      <div class="simply-nav-wrap"><div class="simply-header-inner">
        <a class="simply-logo" href="index.html"><img src="assets/logo-original.webp" alt="LK Eletrônicos"></a>
        <div class="simply-categories">
          <button class="simply-cat-btn" id="menuToggle" aria-label="Abrir categorias"><span class="simply-hamb"><i></i><i></i><i></i></span><span class="simply-cat-label">Categorias</span></button>
          <nav class="main-nav simply-category-menu" id="mainNav"><a href="catalogo.html?modo=ofertas"><strong>Ofertas</strong></a>${catLinks}<a class="all-cats" href="catalogo.html"><strong>VER MAIS CATEGORIAS</strong></a></nav>
        </div>
        <form class="site-search simply-search" id="globalSearch"><input id="globalSearchInput" type="search" list="searchSuggestions" placeholder="O que você procura? " autocomplete="off"><datalist id="searchSuggestions">${[...products.slice(0,30).map(p=>`<option value="${esc(p.name)}">`),...categories.map(c=>`<option value="${esc(c.name)}">`)].join('')}</datalist><button aria-label="Pesquisar"><svg viewBox="0 0 512 512"><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/></svg></button></form>
        <button class="cart-btn simply-cart" id="cartBtn" aria-label="Abrir carrinho"><span>Meu Carrinho</span><svg class="simply-cart-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 4h2l2.3 10.1a2 2 0 0 0 2 1.6h7.8a2 2 0 0 0 1.9-1.5L21 8H7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="10" cy="20" r="1.35"/><circle cx="18" cy="20" r="1.35"/></svg><b id="cartCount">0</b></button>
      </div></div>
    </header>`;
  }
  function footer(){
    const catLinks=categories.map(c=>`<a href="catalogo.html?categoria=${encodeURIComponent(c.slug)}">${esc(c.name)}</a>`).join('');
    return `<footer class="site-footer-v5 simply-footer"><div class="footer-grid">
      <div><strong>Institucional</strong><a href="pagina.html?tipo=quem-somos">Quem Somos</a><a href="pagina.html?tipo=garantia">Política de Garantia</a><a href="pagina.html?tipo=pagamentos">Formas de Pagamento</a><a href="pagina.html?tipo=entregas">Envios e Entregas</a><a href="pagina.html?tipo=privacidade">Política de Privacidade</a></div>
      <div><strong>Categorias</strong>${catLinks}</div>
      <div><strong>Contatos</strong><p>Rua: Des Lauro Nogueira, 1500 - Papicu</p><a href="${genericWa()}" target="_blank" rel="noopener">${esc(settings.whatsappDisplay||'(55) 85 98210-9948')}</a></div>
      <div><strong>Redes Sociais</strong><a href="https://www.instagram.com/lk.eletronicosoficial" target="_blank" rel="noopener">Instagram</a></div>
    </div><div class="footer-bottom"><span>${esc(settings.storeName||'LK Eletrônicos')}</span></div></footer>`;
  }
  function mountChrome(active=''){
    applyTheme();
    const h=$('#siteHeader'),f=$('#siteFooter'); if(h)h.innerHTML=header(active); if(f)f.innerHTML=footer();
    if(!$('#cartDrawer')) document.body.insertAdjacentHTML('beforeend',cartMarkup());
    if(settings.floatingWhatsapp!==false && !$('#floatingWa')) document.body.insertAdjacentHTML('beforeend',`<a id="floatingWa" class="floating-wa" href="${genericWa()}" target="_blank" rel="noopener" aria-label="WhatsApp">WA</a>`);
    bindChrome();renderCart();cookieNotice();
  }
  function bindChrome(){
    $('#menuToggle')?.addEventListener('click',()=>$('#mainNav')?.classList.toggle('open'));
    $('#globalSearch')?.addEventListener('submit',e=>{e.preventDefault();const q=$('#globalSearchInput').value.trim();if(q)location.href=`catalogo.html?q=${encodeURIComponent(q)}`});
    $('#cartBtn')?.addEventListener('click',openCart);
    $('#cartClose')?.addEventListener('click',closeCart);
    $('#cartBackdrop')?.addEventListener('click',closeCart);
    $('#cartCheckout')?.addEventListener('click',()=>{if(!cart.length)return;location.href='finalizar.html'});
  }
  function isSoldout(p){return !productAvailable(p)}
  function imageMarkup(p,cls='product-image'){
    const img=(p.images||[]).filter(Boolean)[0];
    if(img)return `<img class="${cls}" src="${esc(img)}" alt="${esc(p.name)}" loading="lazy">`;
    return `<div class="placeholder-product ${esc(p.accent||'creator')}"><span>${esc(p.brand||'LK')}</span><i></i></div>`;
  }
  function stockBadge(p){
    if(isSoldout(p))return `<span class="status-badge soldout">Esgotado</span>`;
    if(p.status==='order')return `<span class="status-badge order">Sob encomenda</span>`;
    if(p.stockMode==='numeric')return `<span class="status-badge available">${Number(p.stock)} em estoque</span>`;
    return `<span class="status-badge available">Disponível</span>`;
  }
  function productCard(p,{compact=false}={}){
    const discount=productDiscount(p),sold=isSoldout(p);
    return `<article class="shop-card ${compact?'compact':''}">
      <a class="shop-card-media" href="produto.html?id=${encodeURIComponent(p.id)}">${imageMarkup(p)}${discount?`<span class="offer-badge">-${discount}%</span>`:''}${sold?'<span class="soldout-overlay">Esgotado</span>':''}</a>
      <div class="shop-card-body">
        <a class="shop-card-title" href="produto.html?id=${encodeURIComponent(p.id)}">${esc(p.name)}</a>
        <div class="shop-price"><strong>${money(p.price)}</strong>${p.oldPrice&&Number(p.oldPrice)>Number(p.price)?`<small>${money(p.oldPrice)}</small>`:''}</div>
      </div>
    </article>`;
  }
  function addToCart(id,qty=1,variation=''){
    refresh();const p=products.find(x=>x.id===id);if(!productAvailable(p))return false;
    qty=Math.max(1,Number(qty)||1);const key=`${id}::${variation||''}`;const existing=cart.find(i=>i.key===key);
    if(existing)existing.qty+=qty;else cart.push({key,id,variation:variation||'',qty});
    saveLKCart(cart);renderCart();toast('Adicionado ao pedido.');return true;
  }
  function removeFromCart(key){cart=cart.filter(i=>i.key!==key);saveLKCart(cart);renderCart()}
  function updateQty(key,delta){const item=cart.find(i=>i.key===key);if(!item)return;item.qty=Math.max(1,item.qty+delta);saveLKCart(cart);renderCart()}
  function cartDetailed(){refresh();return cart.map(i=>{const p=products.find(x=>x.id===i.id);return p?{...i,p,subtotal:Number(p.price)*Number(i.qty)}:null}).filter(Boolean)}
  function cartTotal(){return cartDetailed().reduce((s,i)=>s+i.subtotal,0)}
  function cartMarkup(){return `<div class="cart-layer" id="cartDrawer" aria-hidden="true"><div class="cart-backdrop" id="cartBackdrop"></div><aside class="cart-panel"><div class="cart-head"><div><span>SEU PEDIDO</span><h2>Itens selecionados</h2></div><button id="cartClose" aria-label="Fechar">×</button></div><div class="cart-items" id="cartItems"></div><div class="cart-summary"><div><span>Total estimado</span><strong id="cartTotal">R$ 0,00</strong></div><button class="primary-action full" id="cartCheckout">Continuar para WhatsApp</button><small>O pagamento e a confirmação final serão combinados com a equipe da LK.</small></div></aside></div>`}
  function renderCart(){
    refresh();const details=cartDetailed();const count=cart.reduce((s,i)=>s+Number(i.qty||0),0);const cc=$('#cartCount');if(cc)cc.textContent=count;
    const box=$('#cartItems');if(!box)return;
    box.innerHTML=details.length?details.map(i=>`<article class="cart-item"><div class="cart-thumb">${imageMarkup(i.p,'')}</div><div class="cart-info"><strong>${esc(i.p.name)}</strong>${i.variation?`<span>${esc(i.variation)}</span>`:''}<small>${money(i.p.price)} cada</small><div class="qty-control"><button data-minus="${esc(i.key)}">−</button><b>${i.qty}</b><button data-plus="${esc(i.key)}">+</button><button class="remove" data-remove="${esc(i.key)}">Remover</button></div></div><strong>${money(i.subtotal)}</strong></article>`).join(''):`<div class="cart-empty"><strong>Seu pedido está vazio.</strong><p>Adicione produtos para enviar tudo de uma vez pelo WhatsApp.</p><a href="catalogo.html">Ver catálogo</a></div>`;
    const t=$('#cartTotal');if(t)t.textContent=money(cartTotal());const checkout=$('#cartCheckout');if(checkout)checkout.disabled=!details.length;
    $$('[data-minus]',box).forEach(b=>b.onclick=()=>updateQty(b.dataset.minus,-1));$$('[data-plus]',box).forEach(b=>b.onclick=()=>updateQty(b.dataset.plus,1));$$('[data-remove]',box).forEach(b=>b.onclick=()=>removeFromCart(b.dataset.remove));
  }
  function openCart(){renderCart();const d=$('#cartDrawer');d?.classList.add('open');d?.setAttribute('aria-hidden','false');document.body.classList.add('no-scroll')}
  function closeCart(){const d=$('#cartDrawer');d?.classList.remove('open');d?.setAttribute('aria-hidden','true');document.body.classList.remove('no-scroll')}
  function bindAddButtons(root=document){$$('[data-add]',root).forEach(b=>b.onclick=()=>{if(addToCart(b.dataset.add,1,''))openCart()})}
  function toast(message){let t=$('#siteToast');if(!t){t=document.createElement('div');t.id='siteToast';t.className='site-toast';document.body.appendChild(t)}t.textContent=message;t.classList.add('show');clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove('show'),2200)}
  function cookieNotice(){if(localStorage.getItem('lkCookieNotice'))return;if($('#cookieNotice'))return;document.body.insertAdjacentHTML('beforeend','<div class="cookie-notice" id="cookieNotice"><div class="cookie-copy"><span>Usamos cookies para personalizar conteúdos e melhorar a sua experiência. Ao navegar neste site, você concorda com nossa política de privacidade.</span></div><a class="cookie-policy" href="pagina.html?tipo=privacidade">Política de Privacidade</a><button id="cookieOk">Prosseguir</button></div>');$('#cookieOk').onclick=()=>{localStorage.setItem('lkCookieNotice','ok');$('#cookieNotice').remove()}}
  function cartMessage(customer={}){
    const details=cartDetailed();const code=`LK-${Date.now().toString(36).slice(-5).toUpperCase()}`;
    const domain=(settings.domain||'lkeletronicos.com.br').replace(/^https?:\/\//,'').replace(/\/$/,'');
    const lines=[`Olá, LK! Quero confirmar este pedido:`,``,...details.flatMap((i)=>[`${i.qty}x ${i.p.name}`,i.p.sku?`Código: ${i.p.sku}`:null,i.variation?`Variação: ${i.variation}`:null,`Preço unitário: ${money(i.p.price)}`,`Subtotal: ${money(i.subtotal)}`,`Produto: https://${domain}/produto.html?id=${encodeURIComponent(i.p.id)}`,``].filter(Boolean)),`Total estimado: ${money(cartTotal())}`];
    if(customer.delivery)lines.push(`Entrega: ${customer.delivery}${customer.cep?` • CEP ${customer.cep}`:''}`);if(customer.note)lines.push(`Observação: ${customer.note}`);lines.push(`Pedido: ${code}`);return lines.join('\n');
  }
  return {settings:()=>settings,categories:()=>categories,products:()=>products,money,esc,categoryName,mountChrome,productCard,stockBadge,imageMarkup,isSoldout,addToCart,bindAddButtons,openCart,closeCart,cartDetailed,cartTotal,cartMessage,genericWa,toast,refresh};
})();
window.addEventListener('lk-cart-updated',()=>LKUI.refresh());
